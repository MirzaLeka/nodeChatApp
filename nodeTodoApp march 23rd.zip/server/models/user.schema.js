const { Schema, model } = require('mongoose');
const { generateHashedPassword } = require('../service/encryption.service');
const removeKeys = require('../utils/removeKeys');

const UserSchema = new Schema({
    username: {
        type: String,
        required: true,
        trim: true,
        minlength: 6,
        unique: true,
        default: ''
    },
    email: {
        type: String,
        required: true,
        minlength: 1,
        trim: true,
        unique: true,
        default: '',
    },
    password: {
        type: String,
        require: true,
        minlength: 8
    },
    tokens: [{
        access: {
            type: String,
            required: true
        },
        token: {
            type: String,
            required: true
        }
    }],
    dateRegistered: {
        type: String
    },
    todosCreated: {
        type: Number,
        default: 0
    }
});


// Overrides results and removes sensitive properties from response
UserSchema.methods.toJSON = function() {
    const user = this;

    // toObject() takes mongoose object (user) and converts into regular object
    return removeKeys(user.toObject(), ['password', 'tokens']);
}

// Fires before save. Ideal for hashing passowrds
UserSchema.pre('save', async function(next) {
    var user = this;

    if ( user.isModified('password') ) {
        user.password = await generateHashedPassword(user.password);
        next();
    } else {
       next();
    }

});


module.exports = model('User', UserSchema);


// UserSchema.methods.generateAuthToken = function() { // instance functions // arrow functions don't bind this keyword
// var user = this; // same idenfifier as user in other files

// /* Creating new token */

// var access = 'auth';
// var token = jwt.sign({_id: user._id.toHexString(), access}, process.env.JWT_SECRET).toString(); // access : access inside {}

// /* We push new object into tokens array with params defined above */

// user.tokens = user.tokens.concat([{access, token}]);

// /* Now we need to save changes we updated above */

// return user.save().then(() => {
//     return token;
// }); // last then((token) => {}) we used everywhere before will be chained in server file so we don't need it here

// };

/* Deleting token when user logs out */

// UserSchema.methods.removeToken = function (token) {
//     var user = this;

//   return user.update({
//         $pull: {
//             tokens: {token} // pull token that matche ours token
//         }
//     });

// };

/* Used for model methods, unlike previous which were used for instance methods */
// UserSchema.statics.findByToken = function (token) {
//     var User = this;

//     // instance methods get called with induvidual documents
//     // model methos get called with modelas this binding

//     var decoded;

//     try {
//         decoded = jwt.verify(token, process.env.JWT_SECRET); // try and catch if jwt verification fails
//     } catch (e) {
//         // return new Promise((resolve, reject) => {
//         //     reject(); // if error we'll always reject so our success field will never fire
//         // });
//         return Promise.reject(); // same thing, simplified // text inside reject() parentheses will be our error e in server.js file /users/me
//     }

//     // find by token is now completed

//     // if verification succeeded

//     return User.findOne({
//         '_id': decoded._id,
//         'tokens.token' : token,
//         'tokens.access' : 'auth'
//     });

// };

    /* Another model method */

// UserSchema.statics.findByCredentials = function (email, password) {
//     var User = this;

//     return User.findOne({email}).then((user) => {
//         if (!user) {
//             return Promise.reject(); // if there is no user no need to check does plain text PW matches the hashed one
//         }

//         return new Promise((resolve, reject) => { //bcrypt only supports callbacks, so we're creating new Promise so we cna continue using promises

//             bcrypt.compare(password, user.password, (err, res) => {

//                 if (res) {
//                     resolve(user);
//                 } else {
//                     reject();
//                 }

//             });
//         });
//     });

// };


/* We'll hash password before we save doc to DB. That's why we're using pre keyword */
