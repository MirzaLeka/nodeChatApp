
const saveLog = data => {

  const silent = process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'staging';

  if (silent || !data) return;

  // Save to MongoDB

}

const retrieveLog = (query) => {};

const deleteLog = (query) => {};
