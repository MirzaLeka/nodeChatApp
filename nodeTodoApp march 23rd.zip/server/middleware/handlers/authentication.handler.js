// var User = require('../../models/user.schema');
const { findByToken } = require('../../service/authentication.service')
const createError = require('http-errors');
const validateJWT = require('../validators/token.validator');

module.exports.authenticateUser = async (req, res, next) => {

  const token = validateJWT(req.header('x-auth'));
  const user = await findByToken(token);

  if (!user) {
    throw createError(401);
  }

  req.user = user;
  req.token = token;
  next();
};

const validateJWT = (token) => {

  if (!token || !isJWT(token)) {
    throw createError(401);
  }
}


// module.exports.authenticateUser = (req, res, next) => {

//     const token = req.header('x-auth');

//     /* This method will find user related to that token and return it in a promise */
//     User.findByToken(token).then((user) => {
//       if (!user) { // token was OK, but query couldn't find user
//         return Promise.reject();
//       }

//       req.user = user; // req.quthor = author
//       req.token = token;
//       next();

//     }).catch((e) => {
//       res.status(401).send();
//     });

//   };

// module.exports.authenticateAdmin = (req, res, next) => {

//     var token = req.header('x-auth');

//     /* This method will find user related to that token and return it in a promise */
//     User.findByToken(token).then((user) => {
//       if (!user) { // token was OK, but query couldn't find user
//         return Promise.reject();
//       }

//       req.user = user;
//       req.token = token;
//       next();

//     }).catch((e) => {
//       res.status(401).send();
//     });

//   };
