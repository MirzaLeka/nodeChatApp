const rateLimiter = require('express-rate-limit');

const limiter = (windowMs, max) => rateLimiter({
  windowMs: windowMs * 1000,
  max,
  message: {
    code: 429,
    message: 'Too many requests'
  }
});

module.exports.registrationLimiter = (windowMs, max) => limiter(windowMs, max);
