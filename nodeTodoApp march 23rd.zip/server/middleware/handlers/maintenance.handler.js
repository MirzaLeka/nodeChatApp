module.exports = (req, res, next) => {

  if (!process.env.MAINTENANCE) {
    res.status(503).send({ status: 503, message: 'Site under maintenance' });
  }
  next();
}
