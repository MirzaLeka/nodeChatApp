module.exports = (error, req, res, next) => {
    const status = error.status || res.statusCode || 500;
    const message = error.message || 'Something went wrong';

    res.status(status).send({ status, message });
  }
