const createError = require('http-errors');

module.exports = (req, res, next) => {

  if (!req.body || req.body.maintenance === undefined) {
    throw createError(400);
  }

  if (typeof req.body.maintenance !== 'boolean') {
    throw createError(422);
  }

  isMaintenance = req.body.maintenance;

  next();
}
