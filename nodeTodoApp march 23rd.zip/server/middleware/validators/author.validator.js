const createError = require('http-errors');
const { validateUsername, validateEmail, validatePassword } = require('../utils/author.util');
const { cleanCredentials } = require('../utils/clean.util');


module.exports.validateRegister = (req, res, next) => {

  if (!req.body) {
    throw createError(400, 'Invalid data provided');
  }

  req.body = cleanCredentials(req.body);

  if (!validateUsername(req.body.username)) {
    throw createError(422, 'Username must be between 6 and 24 characters and must not include spaces');
  }

  if (!validateEmail(req.body.email)) {
    throw createError(422, 'Invalid email provided');
  }

  if (!validatePassword(req.body.password)) {
    throw createError(422, 'Password must be between 8 and 32 characters and contain one uppercase and lowercase letter, one number and one symbol');
  }

  next();
}

module.exports.validateLogin = (req, res, next) => {

  if (!req.body) {
    throw createError(400, 'Invalid data provided');
  }

  req.body = cleanRequest(req.body);

  if (!validateEmail(req.body.email)) {
    throw createError(422, 'Invalid email provided');
  }

  if (!req.body.password || !req.body.password.trim().length) {
    throw createError(422, 'Invalid password provided');
  }

  next();
}

module.exports.validateAuthorId = (req, res, next) => {

  if (!validateObjectId(req.params._id)) {
    throw createError(400, 'Invalid data provided');
  }

  next();
}

function validateRegex(value, key) {
  switch (key) {
    case 'username':
      return /\d/.test(value) && /[a-z]/i.test(value);
    default:
      return /\d/.test(value) && /[a-z]/i.test(value) && /[$-/:-?{-~!"^_`\[\]]/.test(value)
  }
}
