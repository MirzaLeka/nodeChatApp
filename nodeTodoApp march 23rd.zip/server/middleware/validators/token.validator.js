const { isJWT } = require('validator');
const createError = require('http-errors');

module.exports = (bearerToken) => {

  if (!bearerToken) {
    throw createError(401);
  }

  const [ bearer, token ] = bearerToken.split(' ');

  if (!isValidBearer(bearer)) {
    throw createError(401);
  }

  if (!isValidToken(token)) {
    throw createError(401);
  }

  return token;
}

const isValidToken = (token) => {

  if (!token || !isJWT(token)) {
    return false;
  }

  return true;
}

const isValidBearer = (bearer) => {
  const bearerName = 'Trifecta';

  if (!bearer || bearer !== bearerName) {
    return false;
  }

  return true;
}