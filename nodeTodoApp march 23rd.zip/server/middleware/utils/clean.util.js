const escapeRegExp = require("regex-escape");
const escapeHTML = require('escape-html');
const escapeMongoDB = require('mongo-escape').escape;

const stripRegExp = (text) => stripMongoQuery(escapeRegExp(text));

const stripMongoQuery = (text) => switchQuotes(escapeMongoDB(text));

const switchQuotes = (text) => stripHTML(text.replace(/"/g, "'"));

const stripHTML = (text) => escapeHTML(text);

const cleanData = (data, handler) => {
  Object
    .keys(data)
    .forEach(key => data[key] = handler(data[key]));

  return data;
}

module.exports.cleanCredentials = (data) => cleanData(data, switchQuotes);

module.exports.cleanTodo = (data) => cleanData(data, stripRegExp);
