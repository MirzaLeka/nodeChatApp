const isValidLength = require('./length.util');
const {
  includesEmail,
  includesLetters,
  includesUniCaseLetters,
  includesSpaces,
  includesNumbers,
  includesSymbols
} = require('./pattern.util');

const minPasswordLength = 8; // store in config
const maxPasswordLength = 32;
const minAuthorLength = 6;
const maxAuthorLength = 24;
const doubleBackSlash = '\\'; // is injected if item includes RegExp

const validatePatterns = (text, patterns) => {

  const patternsHive = {
    includesEmail,
    includesLetters,
    includesUniCaseLetters,
    includesNumbers,
    includesSymbols
  }

  return patterns.every(pattern => patternsHive[pattern].test(text)) && !includesSpaces.test(text)
}

// const isValidUsername = (username) => includesEmail.test(username) && !includesSpaces.test(username);

// const isValidEmail = (email) => includeEmail.test(email);

// const isValidPassword = (password) => (includesUniCaseLetters.test(password) && includesNumbers.test(password) && includesSymbols.test(password)) && !includesSpaces.test(password);

const isValidUsername = (username) => validatePatterns(username, ['includesLetters']);

const isValidEmail = (email) => validatePatterns(email, ['includesEmail']);

const isValidPassword = (password) => validatePatterns(password, ['includesUniCaseLetters', 'includesNumbers', 'includesSymbols']);

module.exports.validateUsername = (username) => username && isValidLength(username, minAuthorLength, maxAuthorLength) && isValidUsername(username);

module.exports.validateEmail = (email) => !email || isValidEmail(email);

module.exports.validatePassword = (password) => password && isValidLength(password, minPasswordLength, maxPasswordLength) && isValidPassword(password);

// _!TODO_BODY.includes(doubleBackSlash)
