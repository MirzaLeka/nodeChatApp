const cors = require('cors');
const helmet = require('helmet');
const corsConfig = require('./config/cors.config');

module.exports = (app) => {
  app
  .use(cors(corsConfig))
  .use(helmet())
}
