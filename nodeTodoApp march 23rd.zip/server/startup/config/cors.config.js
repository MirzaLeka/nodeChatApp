const createError = require('http-errors');

const whitelist = ['http://localhost:4200'];

module.exports = {
  origin: (origin, callback) => {
    if (process.env.NODE_ENV === 'development' || whitelist.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(createError(502, 'Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']
}
