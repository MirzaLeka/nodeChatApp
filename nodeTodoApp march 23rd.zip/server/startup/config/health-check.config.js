const healthCheck = require("healthchecks-apis");

module.exports = async (app) => await healthCheck(app, {
    service: {
        config: {
          baseRoute: "demo-app-root-path",
          name: "demo-app",
          description: "Nice demo application :)",
        //   statsLinks: ["https://my-stats/demo-app"],
        //   logsLinks: [
        //     "https://my-logs/demo-app/info",
        //     "https://my-logs/demo-app/debug",
        //   ],
          checks: [
            {
              name: "mongo",
              url: process.env.MONGODB_URI,
              type: "internal",
              interval: 3000,
              check: "mongo",
            },
            // {
            //   name: "service-1",
            //   url: "http://service-1:3001", => LINK /api (swagger)
            //   interval: 1000,
            //   check: "http",
            // },
          ],
        },
      }

});
