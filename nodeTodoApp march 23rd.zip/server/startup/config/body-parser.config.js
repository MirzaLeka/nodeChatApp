module.exports = {
  limit: '1kb'
};
