const { getCurrentDateTime } = require('./time.service');

module.exports = (userRepository) => {

  const addUser = async ({ username, email, password }) => {

    const user = {
      username,
      email,
      password,
      dateRegistered: getCurrentDateTime()
    };

    return userRepository.createUser(user)
  };

  const loginUser = async (userData) => userRepository.loginUser(userData);

  const logoutUser = async ({ email }) => userRepository.logoutUser(email);

  const getUser = async ({ email }) => userRepository.findUser(email);

  return { addUser, loginUser, logoutUser, getUser };
}
