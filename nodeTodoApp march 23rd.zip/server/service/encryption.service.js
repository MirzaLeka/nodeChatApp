const Cryptr = require('cryptr');
const bcrypt = require('bcryptjs');
const createError = require('http-errors');

const encryptDecrypt = (text, method) => new Cryptr(process.env.CRYPT_SECRET)[method](text);

module.exports.encrypt = (text) => encryptDecrypt(text, 'encrypt');

module.exports.decrypt = (text) => encryptDecrypt(text, 'decrypt');


// what if it fails, how do I catch it?
// return reject on purpose
const generateSalt = async () => {
    const saltRounds = 10;

    return new Promise((resolve, reject) => {
        bcrypt.genSalt(saltRounds, (error, salt) => {
            if (error) {
                return reject(error);
            }
            return resolve(salt);
        })
    });
};

const generateHash = async (text, salt) => {
    return new Promise((resolve, reject) => {
        bcrypt.hash(text, salt, (error, hash) => {
            if (error) {
                return reject(error);
            }
            return resolve(hash);
        });
    })
}

const compareHash = async (text1, text2) => {
    return new Promise((resolve, reject) => {
        bcrypt.compare(text1, text2, (_, match) => {
            if (match) {
                resolve(true);
            } else {
                reject(false);
            }

        });
    });
}

module.exports.generateHashedPassword = async (password) => {
    const salt = await generateSalt();
    const hashedPassword = await generateHash(password, salt);

    return hashedPassword;
}

module.exports.comparePassword = async (password, userPassword) => {
    const match = await compareHash(password, userPassword);

    // if promise rejected ?
    if (!match) {
        throw createError(401);
    }
}
