const { createTransport } = require('nodemailer');

const { EMAIL_SERVICE, EMAIL_USER, EMAIL_PASS } = process.env;

module.exports.welcomeEmail = (email) => {

  const transporter = createTransport({
    service: EMAIL_SERVICE,
    auth: {
      user:  EMAIL_USER,
      pass: EMAIL_PASS
    },
    tls: {
      rejectUnauthorized: false
    }
  });

    const mailOptions = {
      from: EMAIL_SERVICE,
      to: email,
      subject: 'Welcome to Todo 4pp!',
      html: "<p>You successfully registered to <a href='https://todo4pp.herokuapp.com' target='_blank'>Todo 4pp</a>. Enjoy using our services.</p>"
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
      }
      // else {
      //   console.log('Email sent: ' + info.response);
      // }
    });

}

module.exports.exitEmail = (email) => {

  const transporter = createTransport({
    service: EMAIL_SERVICE,
    auth: {
      user:  EMAIL_USER,
      pass: EMAIL_PASS
    },
    tls: {
      rejectUnauthorized: false
    }
  });

    const mailOptions = {
      from: EMAIL_SERVICE,
      to: email,
      subject: 'Sorry to see you go!',
      html: "<p>...</p>"
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
      }
      // else {
      //   console.log('Email sent: ' + info.response);
      // }
    });

}
