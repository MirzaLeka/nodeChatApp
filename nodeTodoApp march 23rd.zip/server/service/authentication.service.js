const jwt = require('jsonwebtoken');
const createError = require('http-errors');
const User = require('../models/user.schema');

// TODO Move private methods to Auth Repository after you test everything
const { JWT_SECRET } = process.env;

const generateJWT = (_id, access) => {
    return jwt.sign({ _id, access }, JWT_SECRET, { expiresIn: '365d' }).toString();
}

// let's fail this on purpose
// Async way?
const verifyJWT = (token) => jwt.verify(token, JWT_SECRET);

// clears tokens array
const removeJWT = async (_id) =>  await User.findByIdAndUpdate( { _id }, { tokens: [] });

// array of tokens or single token ?
module.exports.removeToken = async (id) => {

    if (!id) { // ISN'T MONGODB ID
        throw createError(400);
    }

    return removeJWT(id);
};

// can this method fail?
module.exports.generateAuthToken = (user, access) => {
    const token = generateJWT(user._id.toHexString(), access);
    user.tokens = user.tokens.concat([{access, token}]);

    return user.save().then(() => token);
}

module.exports.findByToken = async (token, access) => {

    let decoded;

    try {
        decoded = verifyJWT(token);
    } catch (e) {
        throw createError(500, 'Unable to verify JWT');
    }

    return User.findOne({
        '_id': decoded._id,
        'tokens.token' : token,
        'tokens.access' : access
    });

}