module.exports = (object, arrayOfkeys) => {
  arrayOfkeys.forEach(key => {
    delete object[key]
  })
  return object;
}