const router = require('express').Router();
const { validateRegister } = require('../middleware/validators/author.validator');

// dependency injection
const service = require('./utils/inject')('user.service', 'user.repository');

router

  .post('/register', validateRegister, async (req, res, next) => {

    try {

      const { user, token } = await service.addUser(req.body);

      res.status(201).header('x-auth', token).send(user);

    } catch(e) {
      next(e);
    }

  })

  .post('/login', async (req, res, next) => {

    try {
      const { user, token } = await service.loginUser(req.body);
      res.header('x-auth', token).send(user);

    } catch (e) {
      next(e);
    }

  })

  .get('/:email', async (req, res, next) => {

    try {
      const user = await service.getUser(req.params);
      res.send(user);

    } catch (e) {
      next(e);
    }

  })

  .delete('/logout', async (req, res) => {

    try {
      await service.logoutUser(req.body);
      res.status(204).send();
    } catch (e) {
      res.status(400).send(e);
    }

  })

  .options('*', (res, req) => {
    // res.header('Access-Control-Allow-Methods', 'GET, PATCH, PUT, POST, DELETE, OPTIONS')
    res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, OPTIONS').send();
   })

module.exports = router;
