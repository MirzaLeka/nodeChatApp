
const repository = process.env.NODE_ENV === 'production' ? 'logger.repository.db' : 'logger.repository.file';
const service = require('./utils/inject')('logger.service', repository);

